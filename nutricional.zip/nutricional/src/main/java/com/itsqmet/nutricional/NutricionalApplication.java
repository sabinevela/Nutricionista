package com.itsqmet.nutricional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NutricionalApplication {

	public static void main(String[] args) {
		SpringApplication.run(NutricionalApplication.class, args);
	}

}
